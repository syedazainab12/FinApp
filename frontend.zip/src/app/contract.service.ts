import { Injectable, resolveForwardRef } from '@angular/core';
import Web3 from "web3";
import * as uuid from 'uuid';
declare let window:any;
let tokenAbi = require('../../../../smart-contract-backend/build/contracts/FinanceApp.json')

@Injectable({
  providedIn: 'root'
})
export class ContractService {
private _tokenContractAddress: string = "0x28685BE26b4322fAfA236dC9b400B50b6B15f7c4";

  web3: any;
  accounts: Array<string> =[]
  account: string = "";
  private _tokenContract: any;

  constructor() { 
   
  }

  

  async loadWeb3() {
    if (typeof window.ethereum !== 'undefined') {
     
        window.web3 = new Web3(window.ethereum);
        

        this.accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        this.account = this.accounts[0];
        this.web3 = window.web3;
        this._tokenContract = new this.web3.eth.Contract(tokenAbi.abi, this._tokenContractAddress);
        
    } else if (window.web3) {
      

        window.web3 = new Web3(window.web3.currentProvider);
        this.web3 = window.web3;
        this._tokenContract = new this.web3.eth.Contract(tokenAbi.abi, this._tokenContractAddress);
    } else {
        window.alert('Non-Ethereum browser detected. You Should consider using MetaMask!');
    }
  }

 async getAccount(): Promise<string> {
    
    return Promise.resolve(this.account);
  }

  public async setInsuranceDetails(
   
    insuraceAgency: any,
    typeOfInsurace: any,
    monthlyBillPaid: any
  ): Promise<any> {
    // generate token with uuid
    const uniqToken = uuid.v4();
    let result = {}


   await this._tokenContract.methods.setInsuranceDetails(
      uniqToken, insuraceAgency, typeOfInsurace, monthlyBillPaid
   ).send({ from: this.account }, function (err: any, res: string) {

    if (err) {
      console.log("An error occured", err)
      return
    }
    console.log("Hash of the transaction: " + res)
    result = {
      vId: uniqToken,
      insuranceAgency: insuraceAgency,
      typeOfInsurance: typeOfInsurace,
      monthlyBillPaid: monthlyBillPaid
    }

    

  })

  return Promise.resolve(result);
     
  }

  public async getInsuranceDetails(iId: string): Promise<any> {
    let returnData = {}
    
    let item = await this._tokenContract.methods.getInsuranceDetails(iId).call({ from: this.account }, function (err: any, res: string) {
      
      if (err) {
        console.log("An error occured", err)
        return
      }
      console.log("Hash of the transaction: " + res)
    }).then((result: any) => {
      console.log(result)
      returnData = result;
    })
    
    
   


    return Promise.resolve(returnData);
  }

  public async getAllDetails(): Promise<any> {
    let returnData: any[] = []
    
    let item = await this._tokenContract.methods.getAllInsuranceDetails().call({ from: this.account }, function (err: any, res: string) {
      
      if (err) {
        console.log("An error occured", err)
        return
      }
      console.log("Hash of the transaction: " + res)
    }).then((result: any) => {
      console.log(result)
      returnData = result;
    })
  
    return Promise.resolve(returnData);
} 
}