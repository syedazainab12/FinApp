import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, Validators } from "@angular/forms";
import { ContractService } from "../contract.service";

interface ReturnData{
  vId: string;
  insuranceAgency: string;
  typeOfInsurance: string;
  monthlyBillPaid: number;
}

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.sass']
})
export class FormsComponent  {
  registeredData!: ReturnData;
  tableData : ReturnData[] = [];
  singleDataFormID : string = "";
  fetchSingleData: ReturnData[] = [];
  walletConnected: boolean = false;
  walletAddress: string = "";
  constructor(
    public fb: FormBuilder,
    public contractService: ContractService
  
  
  ) {


    
    }

   registrationForm = this.fb.group({
      insurance: [''],
      typeOfInsurance: [''],
      billPaid: [0],
   
   })

   // make group for the form
   singleDataForm = this.fb.group({
    id: ['', Validators.required],
   })



   GetAllData() {
    let item = this.contractService.getAllDetails();
    item.then((result: any) => {
      console.log(result[0]["insuranceAgency"])
      this.tableData = result;
    })
  }

   connectToWallet() {


   
      // let item = this.contractService.getInsuranceDetails(123)
      // item.then((result: any) => {
      //   console.log(result)
      //   this.registeredData = result;
      // })
    
      this.contractService.loadWeb3().then((result: any) => {
        console.log(result)
        this.walletConnected = true;
        this.contractService.getAccount().then((res=>{
          this.walletAddress = res
        }))

        
        });
      //  let account = await this.contractService.getAccount()
      //  console.log(account);

   }
  
  onSubmit() {
    const insurance = this.registrationForm.get('insurance')?.value;
    const typeOfInsurance = this.registrationForm.get('typeOfInsurance')?.value;
    const billPaid = this.registrationForm.get('billPaid')?.value;
      const itemReturn = this.contractService.setInsuranceDetails(insurance, typeOfInsurance, billPaid);
      itemReturn.then((result: any) => {
        console.log(result)
        this.registeredData = result;
      })
  }

  onSubmitSingleData() {
    this.singleDataFormID = this.singleDataForm.get('id')?.value !;
    const itemReturn = this.contractService.getInsuranceDetails(this.singleDataFormID);
    itemReturn.then((result: any) => {
      console.log(result)
      const newArr = []
      newArr.push(result)
      this.fetchSingleData = newArr;
    })
  }



}



