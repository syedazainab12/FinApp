var FinanceApp=artifacts.require ("./FinanceApp.sol");
module.exports = function(deployer) {
      deployer.deploy(FinanceApp);
}